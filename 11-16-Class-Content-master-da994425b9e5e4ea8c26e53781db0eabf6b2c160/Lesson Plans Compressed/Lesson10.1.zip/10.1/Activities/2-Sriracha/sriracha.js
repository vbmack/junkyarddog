// Simple console.log using Node.js and  terminal/bash.
console.log("Sriracha. Goes great on... nothing");
